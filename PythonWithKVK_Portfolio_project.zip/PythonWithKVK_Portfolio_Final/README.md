# Python With KVK - Portfolio

This project contains a responsive portfolio website for the Python With KVK course.
Replace `static/assets/videos/mybgvideo.mp4` and `static/assets/audio/ambient.mp3` with your own media files.
Run with:
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
